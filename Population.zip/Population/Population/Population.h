

#pragma once

#include <math.h>
#include "PopGraf.h"
namespace Population {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� Population
	/// </summary>
	public ref class Population : public System::Windows::Forms::Form
	{
	public:
		Population(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~Population()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  dataGridView1;

	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  �����ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  ��������ToolStripMenuItem;
	private: System::Windows::Forms::NumericUpDown^  numericUpDown1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::RadioButton^  radioButton1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;

	private: System::Windows::Forms::Label^  label4;

	private: System::Windows::Forms::NumericUpDown^  numericUpDown2;
	private: System::Windows::Forms::NumericUpDown^  numericUpDown3;
	private: System::Windows::Forms::DataGridView^  dataGridView2;

	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::DataGridView^  dataGridView3;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::DataGridView^  dataGridView4;
	private: System::Windows::Forms::DataGridView^  dataGridView5;
	private: System::Windows::Forms::Button^  button4;







	protected: 
		double **kl;
		int size;







	protected: 

	private:
		/// <summary>
		/// ��������� ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ������������ ����� ��� ��������� ������������ - �� ���������
		/// ���������� ������� ������ ��� ������ ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->��������ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->�����ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->numericUpDown1 = (gcnew System::Windows::Forms::NumericUpDown());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->radioButton1 = (gcnew System::Windows::Forms::RadioButton());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->numericUpDown2 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown3 = (gcnew System::Windows::Forms::NumericUpDown());
			this->dataGridView2 = (gcnew System::Windows::Forms::DataGridView());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->dataGridView3 = (gcnew System::Windows::Forms::DataGridView());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->dataGridView4 = (gcnew System::Windows::Forms::DataGridView());
			this->dataGridView5 = (gcnew System::Windows::Forms::DataGridView());
			this->button4 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->BeginInit();
			this->menuStrip1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView5))->BeginInit();
			this->SuspendLayout();
			// 
			// dataGridView1
			// 
			this->dataGridView1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(12, 298);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->Size = System::Drawing::Size(321, 238);
			this->dataGridView1->TabIndex = 0;
			this->dataGridView1->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Population::dataGridView1_CellContentClick);
			// 
			// button1
			// 
			this->button1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->button1->Location = System::Drawing::Point(339, 611);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(164, 23);
			this->button1->TabIndex = 2;
			this->button1->Text = L"���������� ������� ����";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Population::button1_Click);
			// 
			// menuStrip1
			// 
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->��������ToolStripMenuItem, 
				this->�����ToolStripMenuItem});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(674, 24);
			this->menuStrip1->TabIndex = 3;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// ��������ToolStripMenuItem
			// 
			this->��������ToolStripMenuItem->Name = L"��������ToolStripMenuItem";
			this->��������ToolStripMenuItem->Size = System::Drawing::Size(72, 20);
			this->��������ToolStripMenuItem->Text = L"��������";
			this->��������ToolStripMenuItem->Click += gcnew System::EventHandler(this, &Population::��������ToolStripMenuItem_Click);
			// 
			// �����ToolStripMenuItem
			// 
			this->�����ToolStripMenuItem->Name = L"�����ToolStripMenuItem";
			this->�����ToolStripMenuItem->Size = System::Drawing::Size(47, 20);
			this->�����ToolStripMenuItem->Text = L"�����";
			this->�����ToolStripMenuItem->Click += gcnew System::EventHandler(this, &Population::�����ToolStripMenuItem_Click);
			// 
			// numericUpDown1
			// 
			this->numericUpDown1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->numericUpDown1->Location = System::Drawing::Point(559, 106);
			this->numericUpDown1->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {10, 0, 0, 0});
			this->numericUpDown1->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) {2, 0, 0, 0});
			this->numericUpDown1->Name = L"numericUpDown1";
			this->numericUpDown1->Size = System::Drawing::Size(106, 20);
			this->numericUpDown1->TabIndex = 4;
			this->numericUpDown1->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {2, 0, 0, 0});
			// 
			// label1
			// 
			this->label1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(556, 83);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(109, 13);
			this->label1->TabIndex = 5;
			this->label1->Text = L"���������� �������";
			this->label1->Click += gcnew System::EventHandler(this, &Population::label1_Click);
			// 
			// radioButton1
			// 
			this->radioButton1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->radioButton1->AutoSize = true;
			this->radioButton1->Location = System::Drawing::Point(560, 46);
			this->radioButton1->Name = L"radioButton1";
			this->radioButton1->Size = System::Drawing::Size(105, 17);
			this->radioButton1->TabIndex = 6;
			this->radioButton1->TabStop = true;
			this->radioButton1->Text = L"����� ��������";
			this->radioButton1->UseVisualStyleBackColor = true;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(262, 46);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(0, 13);
			this->label2->TabIndex = 7;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(9, 36);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(120, 13);
			this->label3->TabIndex = 8;
			this->label3->Text = L"���������� ���������";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(9, 83);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(224, 13);
			this->label4->TabIndex = 10;
			this->label4->Text = L"���������� ��������� �������� ��������";
			this->label4->Click += gcnew System::EventHandler(this, &Population::label4_Click);
			// 
			// numericUpDown2
			// 
			this->numericUpDown2->DecimalPlaces = 2;
			this->numericUpDown2->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {1, 0, 0, 131072});
			this->numericUpDown2->Location = System::Drawing::Point(12, 52);
			this->numericUpDown2->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {1, 0, 0, 0});
			this->numericUpDown2->Name = L"numericUpDown2";
			this->numericUpDown2->Size = System::Drawing::Size(106, 20);
			this->numericUpDown2->TabIndex = 12;
			// 
			// numericUpDown3
			// 
			this->numericUpDown3->DecimalPlaces = 2;
			this->numericUpDown3->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {1, 0, 0, 131072});
			this->numericUpDown3->Location = System::Drawing::Point(12, 106);
			this->numericUpDown3->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {1, 0, 0, 0});
			this->numericUpDown3->Name = L"numericUpDown3";
			this->numericUpDown3->Size = System::Drawing::Size(106, 20);
			this->numericUpDown3->TabIndex = 13;
			// 
			// dataGridView2
			// 
			this->dataGridView2->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->dataGridView2->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::AllCells;
			this->dataGridView2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView2->Location = System::Drawing::Point(12, 253);
			this->dataGridView2->Name = L"dataGridView2";
			this->dataGridView2->RowHeadersWidth = 40;
			this->dataGridView2->Size = System::Drawing::Size(653, 39);
			this->dataGridView2->TabIndex = 14;
			this->dataGridView2->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Population::dataGridView2_CellContentClick);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(9, 229);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(112, 13);
			this->label5->TabIndex = 15;
			this->label5->Text = L"������ �����������";
			// 
			// button2
			// 
			this->button2->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button2->Location = System::Drawing::Point(545, 224);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(120, 23);
			this->button2->TabIndex = 16;
			this->button2->Text = L"������ ������";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Population::button2_Click);
			// 
			// dataGridView3
			// 
			this->dataGridView3->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->dataGridView3->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::AllCells;
			this->dataGridView3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView3->Location = System::Drawing::Point(12, 179);
			this->dataGridView3->Name = L"dataGridView3";
			this->dataGridView3->RowHeadersWidth = 40;
			this->dataGridView3->Size = System::Drawing::Size(653, 39);
			this->dataGridView3->TabIndex = 17;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(12, 155);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(133, 13);
			this->label6->TabIndex = 18;
			this->label6->Text = L"����������� ���� �����";
			// 
			// button3
			// 
			this->button3->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->button3->Location = System::Drawing::Point(545, 150);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(120, 23);
			this->button3->TabIndex = 19;
			this->button3->Text = L"������ ������";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Population::button3_Click);
			// 
			// dataGridView4
			// 
			this->dataGridView4->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->dataGridView4->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView4->Location = System::Drawing::Point(339, 298);
			this->dataGridView4->Name = L"dataGridView4";
			this->dataGridView4->RowHeadersWidth = 80;
			this->dataGridView4->Size = System::Drawing::Size(326, 238);
			this->dataGridView4->TabIndex = 0;
			// 
			// dataGridView5
			// 
			this->dataGridView5->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->dataGridView5->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::AllCells;
			this->dataGridView5->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView5->Location = System::Drawing::Point(12, 542);
			this->dataGridView5->Name = L"dataGridView5";
			this->dataGridView5->RowHeadersWidth = 80;
			this->dataGridView5->Size = System::Drawing::Size(653, 39);
			this->dataGridView5->TabIndex = 20;
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(523, 611);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(142, 23);
			this->button4->TabIndex = 21;
			this->button4->Text = L"���������� ������";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Population::button4_Click);
			// 
			// Population
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(674, 646);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->dataGridView5);
			this->Controls->Add(this->dataGridView4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->dataGridView3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->dataGridView2);
			this->Controls->Add(this->numericUpDown3);
			this->Controls->Add(this->numericUpDown2);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->radioButton1);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->numericUpDown1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->menuStrip1);
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"Population";
			this->Text = L"Population";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->EndInit();
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView5))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: void from(int size, double **mass)
			 {
				 for (int i = 0; i < size; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {
						 mass[i][j] = 0;
					 }
				 }			
			 }
	private: void from2(int size, double **vec)
			 {
				 for (int i = 0; i < 1; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {
						 vec[i][j] = 0;
					 }
				 }
			 }
	private: void show2(int size, double **vec)
			 {
				 for (int i = 0; i < 1; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {
						 vec[i][j] = Convert::ToDouble(dataGridView2->Rows[i]->Cells[j]->Value);
					 }
				 }

			 }
	private: void from3(int size, double **X)
			 {
				 for (int i = 0; i < 1; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {
						 X[i][j] = 0;
					 }
				 }
			 }
	private: void show3(int size, double **X)
			 {
				 for (int i = 0; i < 1; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {
						 X[i][j] = Convert::ToDouble(dataGridView3->Rows[i]->Cells[j]->Value);
					 }
				 }

			 }
	private: void from4(int size, double **st)
			 {
				 for (int i = 0; i < size; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {
						 st[i][j] = 0;

					 }
				 }			
			 }
	private: void show4(int size, double **st)
			 {
				 for (int i = 0; i < size; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {
						 dataGridView4->TopLeftHeaderCell->Value = "����";
						 dataGridView4->Rows[i]->Cells[j]->Value = st[i][j];
					 }
				 }

			 }
	private: void from5(int size, double **kl)
			 {
				 for (int i = 0; i < 1; i++)
				 {
					 for (int j = 0; j < size-1; j++)
					 {
						 kl[i][j] = 0;
					 }
				 }
			 }
	private: void show5(int size, double **kl)
			 {
				 for (int i = 0; i < 1; i++)
				 {
					 for (int j = 0; j < size-1; j++)
					 {
						 dataGridView5->TopLeftHeaderCell->Value = "�����������";
						 dataGridView5->Rows[i]->Cells[j]->Value = kl[i][j];
					 }
				 }

			 }
	private: void typing(int size, double **mass)
			 {
				 for (int i = 0; i < size; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {
						 mass[i][j] = Convert::ToDouble(dataGridView1->Rows[i]->Cells[j]->Value);
					 }
				 }

			 }
	private: void show(int size, double **mass)
			 {
				 for (int i = 0; i < size; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {
						 dataGridView1->TopLeftHeaderCell->Value = "������� ����";
						 dataGridView1->Rows[i]->Cells[j]->Value = mass[i][j];
					 }
				 }
			 }
	private: void clear() 
			 {
				 for (int i = 0; i < dataGridView1->Rows->Count; i++)
				 {
					 for (int j = 0; j < dataGridView1->Rows->Count; j++)
					 {
						 dataGridView1->Rows[i]->Cells[j]->Value = 0;
						 dataGridView4->Rows[i]->Cells[j]->Value = 0;
					 }
				 }
				 for (int i = 0; i < 1; i++)
				 {
					 for (int j = 0; j < dataGridView1->Rows->Count - 1; j++)
					 {
						 dataGridView5->Rows[i]->Cells[j]->Value = 0;
					 }
				 }
			 }
	private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) 
			 {

			 }
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 //���������� �������
				 size = Convert::ToInt32(numericUpDown1->Value);
				 double cof = Convert::ToDouble(numericUpDown2->Value);
				 double cof12 = Convert::ToDouble(numericUpDown3->Value);
				 //����� ��� �������
				 double **mass = new double *[size];
				 for (int i = 0; i < size; i++)
				 {
					 mass[i] = new double[size];
				 }
				 double **st = new double *[size];
				 for (int i = 0; i < size; i++)
				 {
					 st[i] = new double[size];
				 }
				 kl = new double *[size];
				 for (int i = 0; i < size; i++)
				 {
					 kl[i] = new double[size];
				 }
				 //������� ��� �������
				 dataGridView1->ColumnCount = size;
				 dataGridView1->RowCount = size;
				 dataGridView4->ColumnCount = size;
				 dataGridView4->RowCount = size;
				 dataGridView5->ColumnCount = size-1;
				 dataGridView5->RowCount = 1;

				 from(size, mass);

				 if (radioButton1->Checked)
				 {
					 typing(size, mass);
				 }

				 mass[size - 1][size - 1] = cof12;
				 for (int i = 1; i < size; i++)
				 {
					 for (int j = 0; j < size - 1; j++)
					 {
						 if (j + 1 == i)
						 {
							 mass[i][j] = cof;
						 }
					 }
				 }
				 for (int i = 0; i < 1; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {
						 mass[i][j] = Convert::ToDouble(dataGridView2->Rows[i]->Cells[j]->Value);
					 }
				 }
				 int u = 0;
				 double max = mass[0][0];
				 for (int i = 0; i < 1; i++) 
				 {
					 for (int j = 0; j < size; j++)
					 {
						 if (mass[i][j] >= max) 
						 {
							 max = mass[i][j];
							 u = j;
						 }
					 }

				 }
				 for (int i = 1; i < size; i++)
				 {
					 if (mass[i][u] != 0)
					 {
						 max = max * mass[i][u];
					 }
				 }

				 double **sum = new double *[size];
				 for (int i = 0; i < size; i++)
				 {
					 sum[i] = new double[size];
				 }
				 from4(size, st);
				 for (int i = 0; i < 1 ; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {

						 sum[i][j] = Convert::ToDouble(dataGridView3->Rows[i]->Cells[j]->Value);

					 }
				 }

				 for (int i = 1; i < size; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {

						 st[i][j] = mass[i][j] * sum[0][i-1];

					 }
				 }
				 if (cof12 != 0)
				 {
					 st[size-1][size-1] = mass[size - 1][size - 1] * sum[0][size-1];
					 st[size-1][size-2] = 0;
				 }
				 from5(size, kl);



				 for (int i = 1; i < size; i++)
				 {
					 for (int j = 0; j < size; j++)
					 {

						 kl[0][i - 1] += st[i][j]; 

					 }
					 kl[0][i - 1] = floor(kl[0][i - 1] * max);
				 }


				 show(size, mass);

				 show4(size, st);
				 show5(size, kl);

				 dataGridView1->AutoResizeRowHeadersWidth(DataGridViewRowHeadersWidthSizeMode::AutoSizeToAllHeaders);
				 dataGridView1->AutoResizeColumns();

				 dataGridView4->AutoResizeRowHeadersWidth(DataGridViewRowHeadersWidthSizeMode::AutoSizeToAllHeaders);
				 dataGridView4->AutoResizeColumns();


				 for (int i = 0; i < size; i++)
				 {
					 delete [] mass[i];
				 }
				 delete[] mass;


			 }
	private: System::Void �����ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 Application::Exit();
			 }
	private: System::Void ��������ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 clear();
			 }
	private: System::Void dataGridView2_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			 }
	private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 int size = Convert::ToInt32(numericUpDown1->Value);
				 double **vec = new double *[size];
				 for (int i = 0; i < size; i++)
				 {
					 vec[i] = new double[size];
				 }

				 //������� ��� �������
				 dataGridView2->ColumnCount = size;
				 dataGridView2->RowCount = 1;

				 from2(size, vec);

				 show2(size, vec);

				 dataGridView2->AutoResizeRowHeadersWidth(DataGridViewRowHeadersWidthSizeMode::AutoSizeToAllHeaders);
				 dataGridView2->AutoResizeColumns();
			 }
	private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e)
			 {
				 int size = Convert::ToInt32(numericUpDown1->Value);
				 double **X = new double *[size];
				 for (int i = 0; i < size; i++)
				 {
					 X[i] = new double[size];
				 }

				 //������� ��� �������
				 dataGridView3->ColumnCount = size;
				 dataGridView3->RowCount = 1;

				 from3(size, X);

				 show3(size, X);

				 dataGridView3->AutoResizeRowHeadersWidth(DataGridViewRowHeadersWidthSizeMode::AutoSizeToAllHeaders);
				 dataGridView3->AutoResizeColumns();
			 }
	private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 PopGraf^ f2 = gcnew PopGraf(this->kl, this->size);
				 f2->Show( this );
			 }
	};
}
